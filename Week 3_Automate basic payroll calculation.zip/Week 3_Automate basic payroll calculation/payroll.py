import csv

def read_csv(file_path):
    with open(file_path, 'r') as file:
        return list(csv.DictReader(file))


def calculate_payroll(employees, salaries):
    payroll_data = []

    salary_map = {s['employee_id']: s for s in salaries}

    for emp in employees:
        emp_id = emp['employee_id']

        if emp_id in salary_map:
            sal = salary_map[emp_id]

            payroll_data.append({
                'Employee ID': emp_id,
                'Name': emp['employee_name'],
                'Department': emp['department'],
                'Designation': emp['designation'],
                'Gross Salary': float(sal['gross_salary']),
                'Tax Deduction': float(sal['tax_deduction']),
                'PF Deduction': float(sal['pf_deduction']),
                'Net Salary': float(sal['net_salary'])
            })

    return payroll_data
