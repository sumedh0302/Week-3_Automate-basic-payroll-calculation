from payroll import read_csv, calculate_payroll
from report_generator import generate_csv_report

employees = read_csv('data/zenvy_employees.csv')
salaries = read_csv('data/zenvy_payroll.csv')

payroll_result = calculate_payroll(employees, salaries)

generate_csv_report(payroll_result, 'monthly_payroll_report.csv')
