import csv

def generate_csv_report(payroll_data, filename):
    if not payroll_data:
        return

    with open(filename, 'w', newline='') as file:
        writer = csv.DictWriter(file, fieldnames=payroll_data[0].keys())
        writer.writeheader()
        writer.writerows(payroll_data)

    print(f"Payroll report generated: {filename}")
